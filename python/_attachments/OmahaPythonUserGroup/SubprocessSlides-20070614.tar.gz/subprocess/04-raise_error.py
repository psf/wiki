#!/usr/bin/env python
   #Run command with arguments.  Wait for command to complete, then
   # return the returncode attribute.
   #
   # Raise an error back to us, by trying to run a non-existent think

import subprocess

retcode = subprocess.call(["jjunk", "-l"])
#!/usr/bin/env python

# Pass command-line arguments by giving Popen a list
import subprocess
subprocess.Popen(["date", "-u"])


# Can also:
    #
    #* Specify a working directory for the child process (the cwd parameter)
    #* Provide or override environment variables (the env parameter)


#!/usr/bin/env python
   #Run command with arguments.  Wait for command to complete, then
   # return the returncode attribute.
   #
   # The arguments are the same as for the Popen constructor.  Example:

import subprocess

retcode = subprocess.call(["ls", "-l"])
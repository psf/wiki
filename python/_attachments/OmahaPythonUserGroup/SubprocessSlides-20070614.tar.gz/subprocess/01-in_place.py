#!/usr/bin/env python

##Simple usage is Popen("cmd"), where "cmd" is the program to be run
#
#    * New process created
#    * Inherits the parent's stdin, stdout, stderr, working directory, and environment variables

import subprocess
subprocess.Popen("date")




from setuptools import setup, Extension
#from distutils.core import setup, Extension

setup(name='magic',
      description='File type identification using libmagic',
      author='Adam Hupp',
      author_email='adam@hupp.org',
      version='0.1',
      test_suite = 'nose.collector',
      py_modules=['magic','cmagic'],
      ext_modules=[Extension('_cmagic', ['magic.i'],
                             libraries=['magic'])],
      )

# This file was created automatically by SWIG 1.3.29.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.

import _cmagic
import new
new_instancemethod = new.instancemethod
def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "thisown"): return self.this.own(value)
    if (name == "this"):
        if type(value).__name__ == 'PySwigObject':
            self.__dict__[name] = value
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    if (name == "thisown"): return self.this.own()
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

def _swig_repr(self):
    try: strthis = "proxy of " + self.this.__repr__()
    except: strthis = ""
    return "<%s.%s; %s >" % (self.__class__.__module__, self.__class__.__name__, strthis,)

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types


MAGIC_NONE = _cmagic.MAGIC_NONE
MAGIC_DEBUG = _cmagic.MAGIC_DEBUG
MAGIC_SYMLINK = _cmagic.MAGIC_SYMLINK
MAGIC_COMPRESS = _cmagic.MAGIC_COMPRESS
MAGIC_DEVICES = _cmagic.MAGIC_DEVICES
MAGIC_MIME = _cmagic.MAGIC_MIME
MAGIC_CONTINUE = _cmagic.MAGIC_CONTINUE
MAGIC_CHECK = _cmagic.MAGIC_CHECK
MAGIC_PRESERVE_ATIME = _cmagic.MAGIC_PRESERVE_ATIME
MAGIC_RAW = _cmagic.MAGIC_RAW
MAGIC_ERROR = _cmagic.MAGIC_ERROR
MAGIC_NO_CHECK_COMPRESS = _cmagic.MAGIC_NO_CHECK_COMPRESS
MAGIC_NO_CHECK_TAR = _cmagic.MAGIC_NO_CHECK_TAR
MAGIC_NO_CHECK_SOFT = _cmagic.MAGIC_NO_CHECK_SOFT
MAGIC_NO_CHECK_APPTYPE = _cmagic.MAGIC_NO_CHECK_APPTYPE
MAGIC_NO_CHECK_ELF = _cmagic.MAGIC_NO_CHECK_ELF
MAGIC_NO_CHECK_ASCII = _cmagic.MAGIC_NO_CHECK_ASCII
MAGIC_NO_CHECK_TROFF = _cmagic.MAGIC_NO_CHECK_TROFF
MAGIC_NO_CHECK_FORTRAN = _cmagic.MAGIC_NO_CHECK_FORTRAN
MAGIC_NO_CHECK_TOKENS = _cmagic.MAGIC_NO_CHECK_TOKENS
magic_open = _cmagic.magic_open
magic_close = _cmagic.magic_close
magic_file = _cmagic.magic_file
magic_buffer = _cmagic.magic_buffer
magic_error = _cmagic.magic_error
magic_setflags = _cmagic.magic_setflags
magic_load = _cmagic.magic_load
magic_compile = _cmagic.magic_compile
magic_check = _cmagic.magic_check
magic_errno = _cmagic.magic_errno


